DEFAULT_INPUTS = {
    "initial_cost": 100000,
    "annual_savings": 20000,
    "discount_rate": 0.1,
    "project_life": 10
}

def calculate_npv(inputs: dict) -> float:
    # TODO: Implement Net Present Value calculation
    pass

def calculate_irr(inputs: dict) -> float:
    # TODO: Implement Internal Rate of Return calculation
    pass