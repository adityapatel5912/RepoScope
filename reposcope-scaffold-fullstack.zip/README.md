# Verdict: Decision Stress-Test Lab

A lab to cross-examine capital proposals against evidence.

## Build Steps

### Stage 1: Foundation
1. Set up FastAPI backend with SQLite.
2. Define core types and API client in React frontend.

### Stage 2: Core Logic
1. Implement the deterministic decision model engine.
2. Build the LLM provider router for BYOK support.

### Stage 3: UI & Visualization
1. Create the ChatPanel for adversarial questioning.
2. Build the Heatmap component for risk visualization.