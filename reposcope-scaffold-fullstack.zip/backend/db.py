import sqlite3
import os

DB_PATH = "verdict.db"

def get_db():
    # TODO: Return a SQLite connection with row factory
    pass

def init_db():
    # TODO: Create tables for decisions, model_inputs, and logs
    pass

def new_id(prefix: str) -> str:
    # TODO: Generate a unique ID with the given prefix
    pass