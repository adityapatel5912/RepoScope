from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from . import state
from .db import init_db

app = FastAPI(title="Verdict")
app.add_middleware(CORSMiddleware, allow_origins=["*"])

@app.on_event("startup")
def startup():
    # TODO: Initialize database schema
    init_db()

@app.post("/decisions")
def create_decision():
    # TODO: Create a new decision record with default inputs
    pass