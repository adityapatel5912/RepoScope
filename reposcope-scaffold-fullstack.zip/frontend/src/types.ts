export interface Decision {
  id: string;
  question: string;
  created_at: string;
}

export interface ModelInput {
  variable: