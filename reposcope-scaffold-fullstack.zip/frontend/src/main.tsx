import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'

// TODO: Add global error telemetry listeners

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)